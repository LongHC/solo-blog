title: 修改tomcat根路径配置
date: '2019-09-07 21:20:41'
updated: '2019-09-07 21:22:11'
tags: [tomcat]
permalink: /articles/2019/09/07/1567862441485.html
---
删除webapps下的所有目录文件
将以下代码添加到server.xml文件中的<host></host>内标签即可
```
<Context path="" docBase="solo" debug="0" reloadable="true"/>
```
